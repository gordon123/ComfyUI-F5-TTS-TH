# 🛠️ ComfyUI-F5-TTS-TH 🇹🇭  
**Custom Node สำหรับแปลงข้อความเป็นเสียงภาษาไทย บน ComfyUI**  

---
### Update
### Muti-Speaker - (28th-AUG-2025)
<img width="1221" height="569" alt="Screenshot 2025-08-28 at 23 47 30" src="https://github.com/user-attachments/assets/5c9d84e9-fb51-44ee-b6cc-b0b377709a45" /> <br>

ใช้ [ชื่อตัวละคร] กำหนด tag ใช้ตัวละครใน prompt และ ส่วนใน Char_name_i ไม่ต้องมี [ ] เช่น ใส่แค่ ```องุ่น```ในช่อง ```character1``` <br>

ตัวอย่าง นิทาน<br>
```
กลีบดาวพาทั้งสองลอยลงสู่ทุ่งกว้าง
ดอกไม้รอบตัวกระซิบกระซาบราวกับรู้ความลับจักรวาล

โลกนี้จะเปิดทางให้เฉพาะผู้กล้า
ที่มีความเมตตา และความอยากรู้อย่างแท้จริง

[องุ่น] “โอ้โห เงื่อนไขแค่นี้เองเหรอ”
[องุ่น] “ฉันกล้าตั้งแต่ยังไม่รู้เลยว่าจะกล้าไปทำอะไร”

[มะนาว] “ฉันอาจไม่กล้าขนาดนั้นนะ”
[มะนาว] “แต่ฉันอยากรู้จริง ๆ ว่าดอกไม้พวกนี้คิดอะไรอยู่”
[มะนาว] “แล้วทำไมเขาถึงพูดพร้อมกันได้โดยไม่ต้องตั้งกรุ๊ป”

[องุ่น] “เห็นไหม แบบนี้แหละ”
[องุ่น] “ความกล้าของฉัน กับความอยากรู้ของเธอ”
[องุ่น] “รวมกันแล้ว น่าจะเปิดประตูได้สักบานหนึ่งแหละ”

[มะนาว] “ถ้าเปิดไม่ได้…”
[มะนาว] “อย่างน้อยเราก็ได้คำถามเพิ่มอีกสิบคำถาม”
```

### Muti-Speaker - (1st-June-2025)

### วิธีการ ดาวโหลด โมเดล
ให้ไปที่ https://huggingface.co/VIZINTZOR/F5-TTS-THAI/tree/main หรือ https://huggingface.co/VIZINTZOR/F5-TTS-THAI/tree/main/model <br>

สำหรับ ช่อง model_path นี้ ให้ ใส่ <br>

```VIZINTZOR/F5-TTS-THAI/model/model_1000000.pt ``` 

หรือกรณีที่ custom node ไม่ดาวโหลดโมเดลให้อัตโนมัติ ให้เราใช้ wget ดาวโหลด ไฟล์โมเดลไปไว้ในนี้ <br>
```
cd /workspace/ComfyUI/custom_nodes/ComfyUI-F5-TTS-TH/submodules/F5TTS-on-Pod/model/
```

# 🚧 **Underconstruction — IN PROGRESS!** 🚧  
_เสียงไทยที่เท่จนต้องเบิ้ลหูฟัง_  <br>
✅ ทดสอบผ่าน การ์ดrtx 30xxx, 40xx support Python 3.10 Cuda 11.8 - 12.6<br>
❌ rtx 50xx nightly version ยังไม่ support<br>
⁉️การ์ด v100, A100 ของ runpod บางทีก็ได้ บางทีไม่ได้ แอบงงอยู่  <br>
<br>
**25-01-2026** update ComfyUI-F5-TTS-TH v1.1.3 install ผ่าน Custom manager ได้เลย แต่ต้อง ```pip install hf_transfer``` หลัง install เพื่อดาวโหลดไฟล์จาก Hugginface <br>
**28-08-2025** VIZINTZOR/F5-TTS-THAI/model/model_1000000.pt update โมเดลใหม่ แก้ไข model file path เสีย <br>
**06-06-2025** แก้ไข bug Tensor load ไม่เรียกไฟล์ wav, เพิ่ม torchaudio.load(ref_audio) ใน infer report by  @Tonson Nudttapat <br>
**01-06-2025** เพิ่ม โมเดล 700000.pt, update 🎤 F5-TTS-Advance TH 🇹🇭 node ใส่ model path แทน drop down list <br>
**28-05-2025** เพิ่ม โมลเดลใหม่ 6500000.pt ,update อ่านภาษาอังกฤษ ให้เป็นภาษา คาราโอเคะ <br>
**10-05-2025** เพิ่ม โมลเดลใหม่ 6000000.pt, add requirements.txt fix error <br>
**14-05-2025** -Fix bug windows cannot delete tmp, update new model list <br>

## 🎤 เกี่ยวกับโปรเจกต์นี้

`ComfyUI-F5-TTS-TH` คือ Node เสริมสำหรับ [ComfyUI](https://github.com/comfyanonymous/ComfyUI)  
ที่เปิดโอกาสให้คุณสามารถแปลงข้อความเป็นเสียง **ภาษาไทย** ได้แบบง่าย ๆ  
รองรับเสียงอ้างอิง + ปรับแต่งข้อความได้เอง — เพื่อการสร้างเสียงที่เป็นเอกลักษณ์ของคุณเอง 🎧

🧠 พลังมาจากโมเดลภาษาไทย:  
- 🧬 [F5-TTS (Original Repo)](https://github.com/SWivid/F5-TTS)  
- 🇹🇭 [F5-TTS-THAI (Thai Model)](https://github.com/VYNCX/F5-TTS-THAI)  
- 🤗 [Model on HuggingFace](https://huggingface.co/VIZINTZOR/F5-TTS-THAI)  

🔁 พัฒนาต่อยอดมาจาก:  
- 💡 [niknah/ComfyUI-F5-TTS](https://github.com/niknah/ComfyUI-F5-TTS) – **ขอบคุณสำหรับโครงสร้างและแรงบันดาลใจ!**

---
# 🎤 ComfyUI-F5-TTS-TH 🇹🇭

โมดูล Custom Node สำหรับ ComfyUI ที่ให้คุณสามารถใช้โมเดล F5-TTS-THAI ทำ Text-to-Speech (TTS) ภาษาไทย ได้โดยตรง 🎶  
ใช้โมเดลจาก [F5-TTS-THAI (VYNCX)](https://github.com/VYNCX/F5-TTS-THAI) ซึ่งถูกฝึกมาสำหรับเสียงภาษาไทยโดยเฉพาะ  

## 🚀 วิธีติดตั้ง

## Core PyTorch + Audio backend เลือก ให้ตรงกับ Pod ที่ตัวเองใช้ ตัวไดตัวหนึ่ง

### 🔥 Python 3.11 / CUDA 12.8 (ComfyUI Nodes ใหม่ อาจจะต้องลงเวอชั่นนี้)

### 🛠️ Python 3.10 / CUDA 11.8 (F5-TTS ต้นตำหรับ แนะนำเวอชั่นนี้)

### 1. Clone Node
```
cd /workspace/ComfyUI/custom_nodes/
git clone https://github.com/gordon123/ComfyUI-F5-TTS-TH.git
```

ถ้าใคร Install [ComfyUI](https://github.com/gordon123/lean2ComfyUI/blob/main/(Thai)%20%23EP7.%20Install%20witn%20command%20line.md) ด้วย command line ตามนี้

### 🔧 2. Clone repository และติดตั้ง F5-TTS-THAI (แบบ submodule)

```
cd ComfyUI-F5-TTS-TH
git submodule update --init --recursive
```

### 3. สร้าง virtual venv หรือ ใช้ conda ก็เหมือนกัน (ใคร activate venv แล้ว ข้ามไป)
```
python -m venv venv

source venv/bin/activate
```

### 4. ติดตั้ง Package สำหรับรองรับการใช้งานเสียง ( code นี้สำหรับ linux,runpod)
```
apt-get update && apt-get install -y ffmpeg libsndfile1 git
```
สำหรับ Wondows ดูการลง ffmpeg ตามนี้ https://tinyurl.com/installffmpeg1

### 5. ติดตั้ง dependencies 

> [!NOTE]
> Portable version Comfyui เรียก จาก python ใน folder embeded นะครับ ในการใช้ pip <br>
> FILE PATH#_embeded/python.exe -m pip install -r requirements.txt


ปักเวอร์ชันที่ “ปลอดภัยกับ Py3.10”
```
pip install -U setuptools setuptools_scm build cython
```

ปักเวอร์ชันที่ “ปลอดภัยกับ Py3.10”
```
pip install "numpy<2" "soxr==0.5.0.post1" "librosa==0.11.0" "numba==0.58.1" "llvmlite==0.41.1"
```

ตามด้วย
```
pip install -r requirements.txt
python -m nltk.downloader punkt cmudict averaged_perceptron_tagger wordnet omw-1.4
```

### run comfyui ถ้า imported Custom node failed!! ลอง install พวกนี้ ถ้า ยังมี module not found, โยน error ตอน Restart Comfyui ให้ chatGPT
```
pip install -U wheel
pip install "antlr4-python3-runtime==4.9.3"
pip install -U "sentry-sdk>=2.0.0"
pip install -U pip
pip install -U antlr4-python3-runtime==4.9.3
pip install -U nltk==3.9.1
pip install -U sentry-sdk>=2.0.0
pip install -U wheel
pip install distance>=0.1.3 inflect>=0.3.1
python -m nltk.downloader punkt cmudict averaged_perceptron_tagger wordnet omw-1.4
pip install -U loguru distance inflect
pip install -U "einx>=0.3.0" "einops>=0.6.0" "beartype>=0.18" "rotary-embedding-torch>=0.5.3"
pip install -U "pandas==2.2.3" "pyarrow>=14" fsspec xxhash dill multiprocess aiohttp
pip install -U pyparsing cycler kiwisolver contourpy fonttools
pip install -U "encodec==0.1.1"
```

### run comfyui
```
cd /workspace/ComfyUI
pkill -f "python main.py" || true
python main.py --listen
```
---

### 6. Custom Node ที่แนะนำให้ติดตั้งเพิ่มเติม

| ชื่อ Node | ใช้ทำอะไร | ลิงก์ |
|-----------|------------|-------|
| **rgthree-comfy** | ระบบ UI Manager + ฟีเจอร์จัด Node เป็นกลุ่ม, ตัวเลือก dropdown, dynamic inputs | [github.com/rgthree/rgthree-comfy](https://github.com/rgthree/rgthree-comfy) |
| **ComfyUI Web Viewer** | ใช้ `VrchAudioSaverNode` สำหรับบันทึกเสียงพร้อม metadata ถูกต้อง ไม่เจอ codec error | [github.com/VrchStudio/comfyui-web-viewer](https://github.com/VrchStudio/comfyui-web-viewer) |

Upload audio เสียงของเรา 
https://huggingface.co/spaces/hf-audio/whisper-large-v3
แล้วกด transcribe เพื่อ copy ข้อความมาใช้
---
# F5TTS-Advance Parameters Guide

มาเจาะลึกทีละพารามิเตอร์กันดีกว่าว่าแต่ละตัวมัน “เวิร์ก” ยังไง แล้วถ้าเราเลื่อนค่าไปมาก–น้อย จะได้ผลลัพธ์แบบไหน 🌱

---
## `sample_audio`

- 📥 **เสียงอ้างอิง (reference audio)** ที่ส่งให้ระบบฟังโทนน้ำเสียง ทรวดทรงลมหายใจ  
- 🎯 ไม่มีค่า default เพราะเป็น input สำคัญที่สุด  
  - **แนะนำ**: ไฟล์ WAV mono, 24 kHz, PCM16, ความยาว 5–15 วินาที เสียงชัด ไม่มี noise  

---
## `sample_text`

- ✍️ **ข้อความตรงกับ `sample_audio`** ช่วยให้โมเดลจับคำสัณฐานเสียงได้แม่นยำ  อาจจะใช้ whisper ช่วย 
- 📝 default = `"Text of sample_audio"` แต่ถ้า mismatch คุณภาพเสียงจะดรอป  

---
## `text`

- 🎤 **ข้อความไทย** ที่ต้องการให้โมเดลสังเคราะห์  
- 🏷️ ตั้งเป็น multiline ได้ ยาวได้ตามใจ แต่ต้องไม่เกิน `max_chars`  ค่า default 250 char

---
## `model_name`

- 🗂️ เลือกรุ่นเช็คพอยต์ที่ฝึกมาแล้ว (เช่น `model_475000.pt` หรือ `model_500000.pt`)  
- ⚖️ รุ่นเลขสูงกว่า (เช่น 500 k vs 250 k) ผ่านการฝึกมากกว่า จับ nuances ดีขึ้น แต่ไฟล์ใหญ่ โหลดช้า  

---
## `seed`

- 🎲 ควบคุมความ **determinism** ของโมเดล  
- 🔀 `-1` = random ทุกครั้ง  
- 🔢 `>=0` (เช่น `42`) = ผลซ้ำได้ทุกครั้ง เหมาะกับการเทสต์  

---
## `speed`

- ⏩ อัตราเร็ว–ช้าในการพูด  
  - `1.0` = ปกติ  
  - `>1.0` = ช้าลง  
  - `<1.0` = เร็วขึ้น  
- 🚀 `2.0` ช้าลง 2× ฟังชัด แต่ลากเสียงยืด  
- 🐇 `0.3` เร็วขึ้น ฟังคล่องแต่บางทีอาจฟังยาก  

---
## `remove_silence`

- 🔇 ตัดช่วง **silence** หัว–ท้าย หรือเกินความจำเป็น  
  - `true`  = เสียงต่อเนียน ไม่มีเงียบสะดุด ตั้งไว้ใน code เป็น True เป็นค่า defult
  - `false` = เก็บช่วงเว้นวรรค เหมาะกับงาน pacing ต้นฉบับ  

---
## `cross_fade_duration`

- 🔄 ระยะเวลาที่ใช้ **cross-fade** ระหว่างเฟรมเสียง (วินาที)  
  - `0.0–0.1` = ต่อชิ้นสั้น ฟังเป็นชิ้นชัด  
  - `0.5–1.0` = ต่อเนียนนุ่ม แต่ถ้าเกินอาจจาง  

---
## `nfe_step`

- 🌀 จำนวน **steps** สำหรับ flow-matching  
  - สูง (e.g. max `64`) = คุณภาพดี แต่ช้า  
  - ต่ำ (e.g. min `16`)   = เร็ว แต่เสียงอาจแหบ/มี noise  

---
## `cfg_strength`

- 🎚️ “Classifier-free guidance” strength  
  - สูง max (≥ `4`)  = ตรงข้อความแน่น แต่ sacrifice ความหลากหลาย  
  - ต่ำ min (`1`) = ยืดหยุ่น เสียงสร้างสรรค์ แต่บางทีเบี่ยงเบนจาก prompt  

---
## `max_chars`

- 📜 จำกัดความยาว **ข้อความ** สูงสุดที่โมเดลยอมรับ  250 กำลังดี ไม่งั้น แรมจะหมด
- 🔢 ยิ่งสูง = ใส่ prompt ยาวขึ้น แต่ใช้เวลา/memory เพิ่ม  
- ⚠️ ถ้าล้นอาจตัดข้อความหรือเกิด error

# Error ที่เจอ

![499527034_122133914528650340_4943419405701521218_n](https://github.com/user-attachments/assets/e227d531-0540-45df-9811-aefeeca02929) <br><br>
เวลา install custom node ใหม่ เช็คดูว่า มี import failed ไหม แบบในตัวอย่าง และ เออเร่อ log มันจะแจ้ง ในวงกลม สีน้ำเงิน <br>
ในตัวอย่างนี้ คือเครื่องเรายังไม่ได้ลง package ```nltk```  วิธีแก้คือลง package ตามด้วยชื่อที่มันแจ้ง เช่น ```pip install nltk``` <br>

error เกี่ยวกับ TensorFlow/Transformers import failed ให้ 
```pip install protobuf==3.20.3```

<img width="656" height="222" alt="Screenshot 2025-08-28 at 21 01 48" src="https://github.com/user-attachments/assets/d9ca3581-cab5-4df9-8f47-f47a74e6826a" />
ถ้าเจออะไรแบบนี้ แปะถามได้เลย เพราะในวินโดอาจจะไม่เหมือนกัน

---
> “หยอดพารามิเตอร์ดั่งร่ายมนตร์  
> เสียงไทยจะไหลลื่น ใช่ดั่งฝัน”  

ปรับแต่ละค่าตามโจทย์งานของคุณ — narration, voice-over หรือ chatbot — แล้วลองฟังความเปลี่ยนแปลงดูนะครับ! 🚀

